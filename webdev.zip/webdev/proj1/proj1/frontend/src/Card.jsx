
// // Card.jsx
// import React, { useState } from 'react';

// function Card() {
//     const [selectedCountry, setSelectedCountry] = useState(null);

//     const europeCountries = [
//         { name: 'Germany', imgSrc: './src/assets/country_img/germany.png' },
//         { name: 'Scotland', imgSrc: './src/assets/country_img/scotland.png' },
//         { name: 'UK', imgSrc: './src/assets/country_img/uk.png' },
//         { name: 'European Union', imgSrc: './src/assets/country_img/europe.png' },
//     ];

//     const northAmericaCountries = [
//         { name: 'USA', imgSrc: './src/assets/country_img/usa.png' },
//     ];

//     const australiaCountries = [
//         { name: 'Australia', imgSrc: './src/assets/country_img/australia.png' },
//     ];

//     const handleCountryClick = (countryName) => {
//         setSelectedCountry(countryName);
//     };

//     const clearSelection = () => {
//         setSelectedCountry(null);
//     };

//     const renderCountries = (countries) => (
//         <ul>
//             {countries.map((country) => (
//                 <li
//                     key={country.name}
//                     className={selectedCountry === country.name ? 'selected' : ''}
//                     onClick={() => handleCountryClick(country.name)}
//                 >
//                     <img src={country.imgSrc} alt={country.name} />
//                     {country.name}
//                 </li>
//             ))}
//         </ul>
//     );

//     return (
//         <div className="card-container">
//             <div className="card-title">
//                 <h2>Market Authorization Details</h2>
//             </div>
//             <div className="sections-container">
//                 <div className="section">
//                     <div className="section-header">
//                         <h2 className='continent'>Europe</h2>
//                     </div>
//                     {renderCountries(europeCountries)}
//                 </div>
//                 <div className="section">
//                     <div className="section-header">
//                         <h2 className='continent'>North America</h2>
//                     </div>
//                     {renderCountries(northAmericaCountries)}
//                 </div>
//                 <div className="section">
//                     <div className="section-header">
//                         <h2 className='continent'>Australia</h2>
//                     </div>
//                     {renderCountries(australiaCountries)}
//                 </div>
//             </div>
//             {selectedCountry && (
//                 <button className="clear-button" onClick={clearSelection}>Clear Selection</button>
//             )}
//         </div>
//     );
// }

// export default Card;


import React, { useState } from 'react';

function Card({ setSelectedCountry, setCardType }) {
  const [selectedCountry, setSelectedCountryLocal] = useState(null);

  const europeCountries = [
    { name: 'Germany', imgSrc: './src/assets/country_img/germany.png' },
    { name: 'Scotland', imgSrc: './src/assets/country_img/scotland.png' },
    { name: 'UK', imgSrc: './src/assets/country_img/uk.png' },
    { name: 'European Union', imgSrc: './src/assets/country_img/europe.png' },
  ];

  const northAmericaCountries = [
    { name: 'USA', imgSrc: './src/assets/country_img/usa.png' },
  ];

  const australiaCountries = [
    { name: 'Australia', imgSrc: './src/assets/country_img/australia.png' },
  ];

  const handleCountryClick = (countryName) => {
    setSelectedCountryLocal(countryName);
    setSelectedCountry(countryName);
    setCardType("MA"); // set card type to "MA"
  };

  const clearSelection = () => {
    setSelectedCountryLocal(null);
    setSelectedCountry(null);
  };

  const renderCountries = (countries) => (
    <ul>
      {countries.map((country) => (
        <li
          key={country.name}
          className={selectedCountry === country.name ? 'selected' : ''}
          onClick={() => handleCountryClick(country.name)}
        >
          <img src={country.imgSrc} alt={country.name} />
          {country.name}
        </li>
      ))}
    </ul>
  );

  return (
    <div className="card-container">
      <div className="card-title">
        <h2>Market Authorization Details</h2>
      </div>
      <div className="sections-container">
        <div className="section">
          <div className="section-header">
            <h2 className='continent'>Europe</h2>
          </div>
          {renderCountries(europeCountries)}
        </div>
        <div className="section">
          <div className="section-header">
            <h2 className='continent'>North America</h2>
          </div>
          {renderCountries(northAmericaCountries)}
        </div>
        <div className="section">
          <div className="section-header">
            <h2 className='continent'>Australia</h2>
          </div>
          {renderCountries(australiaCountries)}
        </div>
      </div>
      {selectedCountry && (
        <button className="clear-button" onClick={clearSelection}>Clear Selection</button>
      )}
    </div>
  );
}

export default Card;


